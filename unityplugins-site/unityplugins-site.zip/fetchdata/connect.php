<?php
	$db = mysqli_connect('localhost', 'werplayc_mskh', 'asdf123','werplayc_houseofqa') or die('Could not connect: ' . mysqli_connect_error()); 
?>
