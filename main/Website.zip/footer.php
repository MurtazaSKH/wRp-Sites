<div class="footer-bottom">
               <div class="container">
                
                  <section >
           <header>
            <div id="check1" style="border-image:none;">
            <div class="check1-inner">
              <div class="navbar">
                <div class="logo" id="logobottom" style="top:-68%;">
                  <img src="./rsrc/images/temp.png" /></div>
                  <div id="mobile-check3" style="text-align:center;">
                  
                    we.R.play | Copyright 2016
                  
                </div>
                <div class="check2" style="margin-top: 14px;">
                  <ul class="check2">
                    <li class="first leaf"><a style="color:#4A5459; margin-left:-82px; padding-left:20px; padding-right:20px;" title="" class="hvr-underline-reveal" href="http://press.werplay.com/">Press Kit</a></li>
                    <li class="leaf "><a style="color:#4A5459; padding-left:20px; padding-right:20px;" title="" class="hvr-underline-reveal" id="services" href="contactus.php">Contact Us</a></li>
                    <li class="leaf video"><a style="color:#4A5459; padding-left:20px; padding-right:20px;" title="" class="hvr-underline-reveal" id="about" href="http://portfolio.werplay.com/">Portfolio</a></li>
                    <!-- <li class="leaf"><a style="color:#4A5459; margin-left:203px; padding-left:20px; padding-right:20px;" title="" class="hvr-underline-reveal" href="#">Press Kit</a></li>
                    <li class="leaf"><a style="color:#4A5459; padding-left:20px; padding-right:20px;" title="" class="hvr-underline-reveal" id="services" href="#">Contact Us</a></li> -->
                    <li class="last leaf" style="margin-left:20px;">we.R.play | Copyright 2016</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          </header></section>
        </div>
           
          
               </div>