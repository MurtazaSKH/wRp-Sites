<?php

		$conn = mysqli_connect("localhost", "root", "root", "wrp_site1");

	     // Check connection
	     if (!$conn) {
	         die("Connection failed: " . mysqli_connect_error());
	     }
	     

?>