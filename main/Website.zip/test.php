<?php 

	$time = date("m/d/Y h:i:s a", time() + 14400);
	echo $time;
	
?>